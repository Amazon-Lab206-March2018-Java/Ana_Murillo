package com.anaroja.NinjaDojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NinjaDojoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NinjaDojoApplication.class, args);
	}
}
