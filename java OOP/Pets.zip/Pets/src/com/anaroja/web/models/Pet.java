package com.anaroja.web.models;

public interface Pet {
		String showAffection();
}
