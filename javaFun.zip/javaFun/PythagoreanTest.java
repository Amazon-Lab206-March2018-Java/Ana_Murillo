public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean calculateHypotenuse = new Pythagorean(); 
        System.out.println(calculateHypotenuse.calculateHypotenuse(4,6));
    }
}